#include "enemy.h"
#include "waypoint.h"
#include "tower.h"
#include "utility.h"
#include "mainwindow.h"
#include "audioplayer.h"
#include <QPainter>
#include <QColor>
#include <QDebug>
#include <QMatrix>
#include <QVector2D>
#include <QtMath>
#include <QTime>
#include <QTimer>

static const int Health_Bar_Width = 20;
static int count1=0;
static int count2=0;

const QSize Enemy::ms_fixedSize(44, 44);

Enemy::Enemy(WayPoint *startWayPoint, MainWindow *game)
	: QObject(0)
    , m_active(false)
    , m_fired(false)
    , m_tornado(false)
    , m_maxHp(40)  //40点血
	, m_currentHp(40)
	, m_walkingSpeed(1.0)
    //, m_rotationSprite(0.0)
	, m_pos(startWayPoint->pos())
	, m_destinationWayPoint(startWayPoint->nextWayPoint())
    , m_game(game)
{
    loadSprite();
}

Enemy::~Enemy()
{
	m_attackedTowersList.clear();
	m_destinationWayPoint = NULL;
	m_game = NULL;
}

void Enemy::loadSprite(){
    QPixmap sprite = QPixmap(":/image/enemy1_1_1.png");
    m_Sprite.push_back(sprite);
    QPixmap sprite1= QPixmap(":/image/enemy1_1_2.png");
    m_Sprite.push_back(sprite1);
    QPixmap sprite2= QPixmap(":/image/enemy1_1_3.png");
    m_Sprite.push_back(sprite2);
    QPixmap sprite3= QPixmap(":/image/enemy1_1_4.png");
    m_Sprite.push_back(sprite3);
    QPixmap sprite4= QPixmap(":/image/enemy1_1_5.png");
    m_Sprite.push_back(sprite4);
    QPixmap sprite5= QPixmap(":/image/enemy1_2_1.png");
    m_Sprite.push_back(sprite5);
    QPixmap sprite6= QPixmap(":/image/enemy1_2_2.png");
    m_Sprite.push_back(sprite6);
    QPixmap sprite7= QPixmap(":/image/enemy1_2_3.png");
    m_Sprite.push_back(sprite7);
    QPixmap sprite8= QPixmap(":/image/enemy1_2_4.png");
    m_Sprite.push_back(sprite8);
    QPixmap sprite9= QPixmap(":/image/enemy1_2_5.png");
    m_Sprite.push_back(sprite9);
    QPixmap sprite10= QPixmap(":/image/enemy1_2_6.png");
    m_Sprite.push_back(sprite10);
    QPixmap sprite11= QPixmap(":/image/enemy1_2_7.png");
    m_Sprite.push_back(sprite11);
    QPixmap sprite12= QPixmap(":/image/enemy1_2_8.png");
    m_Sprite.push_back(sprite12);
    QPixmap sprite13= QPixmap(":/image/enemy1_2_9.png");
    m_Sprite.push_back(sprite13);

    QPixmap se1= QPixmap(":/image/fire1.png");
    m_Sprite.push_back(se1);
    QPixmap se2= QPixmap(":/image/fire2.png");
    m_Sprite.push_back(se2);
    QPixmap se3= QPixmap(":/image/fire3.png");
    m_Sprite.push_back(se3);
    QPixmap se4= QPixmap(":/image/tornado1.png");
    m_Sprite.push_back(se4);
    QPixmap se5= QPixmap(":/image/tornado2.png");
    m_Sprite.push_back(se5);

    QPixmap bird= QPixmap(":/image/bird.png");
    m_Sprite.push_back(bird);
    QPixmap bird1= QPixmap(":/image/bird1.png");
    m_Sprite.push_back(bird1);
    QPixmap bird2= QPixmap(":/image/bird2.png");
    m_Sprite.push_back(bird2);
    QPixmap bird3= QPixmap(":/image/bird3.png");
    m_Sprite.push_back(bird3);
    QPixmap bird4= QPixmap(":/image/bird4.png");
    m_Sprite.push_back(bird4);
    QPixmap bird5= QPixmap(":/image/bird5.png");
    m_Sprite.push_back(bird5);
}


void Enemy::doActivate()
{
	m_active = true;
}

void Enemy::move()
{
	if (!m_active)
		return;

	if (collisionWithCircle(m_pos, 1, m_destinationWayPoint->pos(), 1))
	{
		// 敌人抵达了一个航点
		if (m_destinationWayPoint->nextWayPoint())
		{
			// 还有下一个航点
			m_pos = m_destinationWayPoint->pos();
			m_destinationWayPoint = m_destinationWayPoint->nextWayPoint();
		}
		else
		{
			// 表示进入基地
			m_game->getHpDamage();
			m_game->removedEnemy(this);
			return;
		}
	}

	// 还在前往航点的路上
	// 目标航点的坐标
	QPoint targetPoint = m_destinationWayPoint->pos();
	// 未来修改这个可以添加移动状态,加快,减慢,m_walkingSpeed是基准值

	// 向量标准化
    double movementSpeed = m_walkingSpeed;
	QVector2D normalized(targetPoint - m_pos);
    normalized.normalize();
	m_pos = m_pos + normalized.toPoint() * movementSpeed;

	// 确定敌人选择方向
	// 默认图片向左,需要修正180度转右
    //m_rotationSprite = qRadiansToDegrees(qAtan2(normalized.y(), normalized.x()))+90;
    //qAtan2计算幅角，qRadiansToDegrees π转角度
}

void Enemy::draw(QPainter *painter,int level,int waves)
{
	if (!m_active)
		return;

	painter->save();
    painter->setRenderHint(QPainter::Antialiasing, true);
    QPoint healthBarPoint = m_pos + QPoint((-Health_Bar_Width / 2 -3),
                                           (-ms_fixedSize.height() / 3-10));
	// 绘制血条
	painter->setPen(Qt::NoPen);
	painter->setBrush(Qt::red);
	QRect healthBarBackRect(healthBarPoint, QSize(Health_Bar_Width, 2));
	painter->drawRect(healthBarBackRect);

	painter->setBrush(Qt::green);
	QRect healthBarRect(healthBarPoint, QSize((double)m_currentHp / m_maxHp * Health_Bar_Width, 2));
	painter->drawRect(healthBarRect);

    // 绘制偏转坐标,向左上挪一点，到中点位置
    static const QPoint offsetPoint(-ms_fixedSize.width() / 2, -ms_fixedSize.height() / 2);
    painter->translate(m_pos);//将m_pos设置为坐标原点
//	painter->rotate(m_rotationSprite);
	// 绘制敌人
    QTime time=QTime::currentTime();
    if(m_fired){
        if(time.msec()>0&&time.msec()<=333)
            painter->drawPixmap(offsetPoint,m_Sprite[14]);
        else if(time.msec()>333&&time.msec()<=666)
            painter->drawPixmap(offsetPoint,m_Sprite[15]);
        else{
            painter->drawPixmap(offsetPoint,m_Sprite[16]);
            count1++;
        }
        painter->setCompositionMode(QPainter::CompositionMode_DestinationOver);
        if(count1==6){
            m_fired=false;
            count1=0;
        }
    }
    else if(m_tornado){
        if(time.msec()>0&&time.msec()<=250||time.msec()>750&&time.msec()<=999)
            painter->drawPixmap(offsetPoint,m_Sprite[17]);
        else{
            painter->drawPixmap(offsetPoint,m_Sprite[18]);
            count2++;
        }
        painter->setCompositionMode(QPainter::CompositionMode_DestinationOver);
        if(count2==8){
            m_tornado=false;
            count2=0;
        }
    }
    if(level==1){//第一关
        /*if(waves==0){
            if(this->pos().y()<m_destinationWayPoint->pos().y()
                    ||this->pos().y()>m_destinationWayPoint->pos().y())
            {
                    if((time.msec()>=0&&time.msec()<250)
                            ||(time.msec()>=500&&time.msec()<750)){
                        painter->drawPixmap(offsetPoint, m_Sprite[0]);
                    }
                    else
                        painter->drawPixmap(offsetPoint,m_Sprite[1]);
                }

            else if(this->pos().x()<m_destinationWayPoint->pos().x()){
                    if(time.msec()<250&&time.msec()>=0){
                            painter->drawPixmap(offsetPoint,m_Sprite[2]);
                    }

                    else if(time.msec()>=250&&time.msec()<500){
                            painter->drawPixmap(offsetPoint,m_Sprite[3]);
                    }

                    else if(time.msec()>=500&&time.msec()<750){
                            painter->drawPixmap(offsetPoint,m_Sprite[4]);
                    }

                    else{
                            painter->drawPixmap(offsetPoint,m_Sprite[3]);
                    }

            }
            else if(this->pos().x()>m_destinationWayPoint->pos().x()){//只有QImage可以镜像
                    QImage image1=(m_Sprite[2]).toImage();
                    QImage image2=(m_Sprite[3]).toImage();
                    QImage image3=(m_Sprite[4]).toImage();
                    image1 = image1.mirrored(true, false);
                    image2 = image2.mirrored(true, false);
                    image3 = image3.mirrored(true, false);
                    QPixmap pixmap1= QPixmap::fromImage(image1);
                    QPixmap pixmap2= QPixmap::fromImage(image2);
                    QPixmap pixmap3= QPixmap::fromImage(image3);
                    if(time.msec()>=0&&time.msec()<250)
                        painter->drawPixmap(offsetPoint,pixmap1);
                    else if(time.msec()>=250&&time.msec()<500)
                        painter->drawPixmap(offsetPoint,pixmap2);
                    else if(time.msec()>=500&&time.msec()<750)
                        painter->drawPixmap(offsetPoint,pixmap3);
                    else
                        painter->drawPixmap(offsetPoint,pixmap2);
            }
        }
        else{
            if(this->pos().y()<m_destinationWayPoint->pos().y()
                    ||this->pos().y()>m_destinationWayPoint->pos().y()){
                    painter->drawPixmap(offsetPoint,m_Sprite[5]);
            }

            else if(this->pos().x()<m_destinationWayPoint->pos().x()
                    ||this->pos().x()>m_destinationWayPoint->pos().x()){
                    if(time.msec()<125&&time.msec()>=0){
                            painter->drawPixmap(offsetPoint,m_Sprite[6]);
                    }
                    else if(time.msec()<250&&time.msec()>=125){
                            painter->drawPixmap(offsetPoint,m_Sprite[7]);
                    }

                    else if(time.msec()<375&&time.msec()>=250){
                            painter->drawPixmap(offsetPoint,m_Sprite[8]);
                    }

                    else if(time.msec()<500&&time.msec()>=375){
                            painter->drawPixmap(offsetPoint,m_Sprite[9]);
                    }
                    else if(time.msec()<625&&time.msec()>=500){
                        painter->drawPixmap(offsetPoint,m_Sprite[10]);
                    }
                    else if(time.msec()<750&&time.msec()>=625){
                        painter->drawPixmap(offsetPoint,m_Sprite[11]);
                    }
                    else if(time.msec()<875&&time.msec()>=750){
                        painter->drawPixmap(offsetPoint,m_Sprite[12]);
                    }
                    else
                        painter->drawPixmap(offsetPoint,m_Sprite[13]);
                }
        }*/
    }
    else{
        m_currentHp=80;
        if(waves==0){
            if(this->pos().y()<m_destinationWayPoint->nextWayPoint()->pos().y()
                    ||this->pos().y()>m_destinationWayPoint->nextWayPoint()->pos().y())
            {
                QImage image= (m_Sprite[19]).toImage();
                image = image.mirrored(true,false);
                QPixmap pixmap= QPixmap::fromImage(image);
                painter->drawPixmap(offsetPoint,pixmap);
            }
            else if(this->pos().x()>m_destinationWayPoint->nextWayPoint()->pos().x())
            {
                if(time.msec()>=0&&time.msec()<200)
                    painter->drawPixmap(offsetPoint,m_Sprite[20]);
                else if(time.msec()>=200&&time.msec()<400)
                    painter->drawPixmap(offsetPoint,m_Sprite[21]);
                else if(time.msec()>=400&&time.msec()<600)
                    painter->drawPixmap(offsetPoint,m_Sprite[22]);
                else if(time.msec()>=600&&time.msec()<800)
                    painter->drawPixmap(offsetPoint,m_Sprite[23]);
                else
                    painter->drawPixmap(offsetPoint,m_Sprite[24]);
            }
            else if(this->pos().x()<m_destinationWayPoint->nextWayPoint()->pos().x())
            {
                QImage image1=(m_Sprite[20]).toImage();
                QImage image2=(m_Sprite[21]).toImage();
                QImage image3=(m_Sprite[22]).toImage();
                QImage image4=(m_Sprite[23]).toImage();
                QImage image5=(m_Sprite[24]).toImage();
                image1 = image1.mirrored(true, false);
                image2 = image2.mirrored(true, false);
                image3 = image3.mirrored(true, false);
                image4 = image4.mirrored(true, false);
                image5 = image5.mirrored(true, false);
                QPixmap pixmap1= QPixmap::fromImage(image1);
                QPixmap pixmap2= QPixmap::fromImage(image2);
                QPixmap pixmap3= QPixmap::fromImage(image3);
                QPixmap pixmap4= QPixmap::fromImage(image4);
                QPixmap pixmap5= QPixmap::fromImage(image5);
                if(time.msec()>=0&&time.msec()<200)
                    painter->drawPixmap(offsetPoint,pixmap1);
                else if(time.msec()>=200&&time.msec()<400)
                    painter->drawPixmap(offsetPoint,pixmap2);
                else if(time.msec()>=400&&time.msec()<600)
                    painter->drawPixmap(offsetPoint,pixmap3);
                else if(time.msec()>=600&&time.msec()<800)
                    painter->drawPixmap(offsetPoint,pixmap4);
                else
                    painter->drawPixmap(offsetPoint,pixmap5);
            }
        }
    }
    painter->restore();
}

void Enemy::getRemoved()
{
	if (m_attackedTowersList.empty())
		return;

	foreach (Tower *attacker, m_attackedTowersList)
		attacker->targetKilled();
	// 通知game,此敌人已经阵亡
	m_game->removedEnemy(this);
    //m_fired=false;
}

void Enemy::getDamage(int damage , int type)
{
	m_game->audioPlayer()->playSound(LaserShootSound);
	m_currentHp -= damage;

	// 阵亡,需要移除
	if (m_currentHp <= 0)
	{
		m_game->audioPlayer()->playSound(EnemyDestorySound);
		m_game->awardGold(200);
		getRemoved();
	}
    if(type==1){
        getSlow();
    }
    else if(type==2){
        m_fired=true;
        m_currentHp-=damage;
    }
    else if(type==3){
        m_tornado=true;
        m_fired=false;
        m_currentHp-=damage;
    }
}

void Enemy::getAttacked(Tower *attacker)
{
	m_attackedTowersList.push_back(attacker);
}

// 表明敌人已经逃离了攻击范围
void Enemy::gotLostSight(Tower *attacker)
{
    m_attackedTowersList.removeOne(attacker);
}


void Enemy::getSlow()
{
    m_walkingSpeed*=0.5;
}

QPoint Enemy::pos() const
{
    return m_pos;
}
