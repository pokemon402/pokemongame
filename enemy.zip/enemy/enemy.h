#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QList>

class WayPoint;
class QPainter;
class MainWindow;
class Tower;

class Enemy : public QObject
{
	Q_OBJECT
public:
    Enemy(WayPoint *startWayPoint, MainWindow *game);
	~Enemy();

    void draw(QPainter *painter,int level,int waves);
	void move();
    void getDamage(int damage,int type);
	void getRemoved();
	void getAttacked(Tower *attacker);
	void gotLostSight(Tower *attacker);
    void getStandStill();
    void getSlow();
    QPoint pos() const;
    void loadSprite();

public slots:
	void doActivate();

private:
    bool			m_active;
    bool            m_fired;
    bool            m_tornado;
	int				m_maxHp;
	int				m_currentHp;
    double			m_walkingSpeed; //qreal=double
    //qreal			m_rotationSprite; //存储敌人到下一个航点时的图片旋转角度

    QPoint			m_pos;
	WayPoint *		m_destinationWayPoint;
	MainWindow *	m_game;
    QList<Tower *>	m_attackedTowersList;
    QList<QPixmap > m_Sprite;
    static const QSize ms_fixedSize;
    static int      m_count1;//火
    static int      m_count2;//龙卷风
};

#endif // ENEMY_H
